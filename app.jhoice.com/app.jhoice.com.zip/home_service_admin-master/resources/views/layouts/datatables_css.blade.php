<link rel="stylesheet" href="{{asset('vendor/datatables-bs4/css/dataTables.bootstrap4.min.css')}}">
<link rel="stylesheet" href="{{asset('vendor/datatables-fixedcolumns/css/fixedColumns.bootstrap4.min.css')}}">
<link rel="stylesheet" href="{{asset('vendor/datatables-colreorder/css/colReorder.bootstrap4.min.css')}}">
<link rel="stylesheet" href="{{asset('vendor/datatables-rowgroup/css/rowGroup.bootstrap4.min.css')}}">
<link rel="stylesheet" href="{{asset('vendor/datatables-responsive/css/responsive.bootstrap4.min.css')}}">
<link rel="stylesheet" href="{{asset('vendor/datatables-scroller/css/scroller.bootstrap4.min.css')}}">

